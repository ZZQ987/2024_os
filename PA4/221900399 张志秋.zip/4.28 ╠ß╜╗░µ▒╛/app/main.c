#include "myos.h"

int main()
{
    
    while(1)
    {
        myos_write("aaa",3);
        myos_sleep(1);
    }


    
}

