

extern void myos_write(char* s,short l);


extern void myos_sleep(short t);


