#include "myos.h"

int a =10;

int main()
{



    if(myos_fork()==0)
    {   
        a=1;
        while(1)
        {
            myos_write("Ping!",5);
            myos_sleep(a);
        }
    }
    else
    {
        a=2;
        while(1)
        {
            myos_write("Pong!",5);
            myos_sleep(a);
        }
    }

    
}

