#define _XOPEN_SOURCE 700  // 确保启用 POSIX.1-2008 标准功能
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>
#include <string.h>
#include <sys/time.h>


// 全局变量
long long total_points = 1000000;  // 设定总采样点数
long long points_in_circle = 0;    // 记录圆内的点数，这是一个全局变量
pthread_mutex_t mutex;             // 锁

// 核心函数，交给每个线程执行
// void* 作为参数和返回值是固定要求
void* calculate_pi(void* arg) {
    // 先计算每个线程采样次数
    long long points_per_thread = total_points / (long)arg;
    long long local_points_in_circle = 0;
    unsigned int seed = time(NULL) ^ pthread_self();  // 线程私有的随机种子，用于随机数生成

    for (long long i = 0; i < points_per_thread; ++i) {
        // 生成随机数，并归一化到 -1~1
        double x = (double)rand_r(&seed) / RAND_MAX;
        double y = (double)rand_r(&seed) / RAND_MAX;
        // 根据几何知识判断是否在圆中
        if (x * x + y * y <= 1.0) {
            ++local_points_in_circle;
        }
    }

    // 使用互斥锁更新全局变量，加锁——更改——释放锁
    pthread_mutex_lock(&mutex);
    points_in_circle += local_points_in_circle;
    pthread_mutex_unlock(&mutex);

    return NULL;
}

int main(int argc, char *argv[]) {

    // 设置开始结束时间
    struct timeval start, end;
    gettimeofday(&start, NULL);
    // 获取线程数，创建线程数组
    int num_threads = atoi(argv[2]);
    pthread_t threads[num_threads];
    // 初始化锁
    pthread_mutex_init(&mutex, NULL);

    // 创建线程
    for (int i = 0; i < num_threads; ++i) {
        pthread_create(&threads[i], NULL, calculate_pi, (void*)(long)num_threads);
    }

    // 等待所有线程完成
    for (int i = 0; i < num_threads; ++i) {
        pthread_join(threads[i], NULL);
    }
    // 获取结束时间
    // 计算运行时间
    gettimeofday(&end, NULL);
    int microseconds = (end.tv_sec - start.tv_sec) * 1000000LL + (end.tv_usec - start.tv_usec);

    // 销毁锁
    pthread_mutex_destroy(&mutex);
    
    // 根据采样结果估计Pi
    double pi_estimate = (4.0 * points_in_circle) / total_points;
    printf("Estimated Pi: %lf\n", pi_estimate);
    printf("Runtime is %d micros\n",microseconds);

    return 0;
}
